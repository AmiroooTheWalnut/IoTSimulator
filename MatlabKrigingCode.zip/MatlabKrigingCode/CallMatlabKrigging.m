function [predictions,MSE] = CallMatlabKrigging(inputX,series,testingX)
%CALLMATLABKRIGGING Summary of this function goes here
%   Detailed explanation goes here

mainFolder=cd('dace');

[model,performance]=dacefit(inputX',series',@regpoly0,@corrgauss,1,0.01,10);
[predictions,MSE]=predictor(testingX',model);

cd(mainFolder)
end

